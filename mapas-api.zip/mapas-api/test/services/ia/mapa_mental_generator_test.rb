# frozen_string_literal: true

# Roda com o resto da suíte (bin/rails test) ou sozinho, sem Rails:
#   ruby -Itest test/services/ia/mapa_mental_generator_test.rb
require "minitest/autorun"
require "json"
require_relative "../../../app/services/ia/claude_client"
require_relative "../../../app/services/ia/mapa_mental_generator"

class MapaMentalGeneratorTest < Minitest::Test
  class FakeClient
    attr_reader :system, :user

    def initialize(reply) = @reply = reply

    def message(system:, user:, **)
      @system = system
      @user = user
      raise @reply if @reply.is_a?(Exception)

      @reply
    end
  end

  def gerar(reply, text: "Reunião sobre o funil de vendas", focus: "reuniao")
    client = FakeClient.new(reply)
    [Ia::MapaMentalGenerator.new(client: client).call(text: text, focus: focus), client]
  end

  def test_monta_o_mapa_a_partir_do_json
    reply = { title: "Funil GFB", nodes: [{ label: "Decisões", note: "", children: [{ label: "Script de 1h", note: "12 perguntas" }] }] }.to_json
    result, = gerar(reply)
    assert_equal "Funil GFB", result["title"]
    assert_equal "Decisões", result["nodes"][0]["label"]
    assert_equal "12 perguntas", result["nodes"][0]["children"][0]["note"]
    assert_equal [], result["nodes"][0]["children"][0]["children"]
  end

  def test_aceita_cerca_de_codigo_e_texto_em_volta
    result, = gerar("Aqui está:\n```json\n{\"title\":\"X\",\"nodes\":[{\"label\":\"A\"}]}\n```")
    assert_equal "A", result["nodes"][0]["label"]
  end

  def test_foco_vai_para_o_prompt_e_foco_invalido_vira_processo
    _, client = gerar('{"title":"X","nodes":[{"label":"A"}]}', focus: "reuniao")
    assert_includes client.system, "RESUMIR UMA REUNIÃO"
    _, client = gerar('{"title":"X","nodes":[{"label":"A"}]}', focus: "qualquer coisa")
    assert_includes client.system, "MAPEAR UM PROCESSO"
  end

  def test_limpa_vtt_antes_de_enviar
    vtt = "WEBVTT\n\n1\n00:00:01.000 --> 00:00:03.000\nOlá pessoal\n"
    _, client = gerar('{"title":"X","nodes":[{"label":"A"}]}', text: vtt)
    assert_includes client.user, "Olá pessoal"
    refute_includes client.user, "-->"
    refute_includes client.user, "WEBVTT"
  end

  def test_limita_profundidade_e_quantidade
    deep = { label: "n1", children: [{ label: "n2", children: [{ label: "n3", children: [{ label: "n4", children: [{ label: "n5" }] }] }] }] }
    many = Array.new(200) { |i| { label: "t#{i}" } }
    result, = gerar({ title: "X", nodes: [deep] + many }.to_json)
    n4 = result["nodes"][0]["children"][0]["children"][0]["children"][0]
    assert_equal "n4", n4["label"]
    assert_empty n4["children"]
    total = ->(ns) { ns.sum { |n| 1 + total.(n["children"]) } }
    assert_equal Ia::MapaMentalGenerator::MAX_NODES, total.(result["nodes"])
  end

  def test_texto_vazio_gera_erro
    assert_raises(ArgumentError) { gerar("{}", text: "  \n ") }
  end

  def test_resposta_sem_topicos_ou_quebrada
    assert_raises(Ia::MapaMentalGenerator::InvalidOutput) { gerar('{"title":"X","nodes":[]}') }
    assert_raises(Ia::MapaMentalGenerator::InvalidOutput) { gerar("não sei") }
    assert_raises(Ia::MapaMentalGenerator::InvalidOutput) { gerar('{"title": "X", "nodes": [') }
  end

  def test_propaga_rate_limit
    assert_raises(Ia::ClaudeClient::RateLimited) { gerar(Ia::ClaudeClient::RateLimited.new("429")) }
  end

  def test_cliente_sem_chave
    err = assert_raises(Ia::ClaudeClient::NotConfigured) do
      Ia::ClaudeClient.new(api_key: "").message(system: "s", user: "u")
    end
    assert_match "ANTHROPIC_API_KEY", err.message
  end
end
