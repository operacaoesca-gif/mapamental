# frozen_string_literal: true

require "test_helper"

module Api
  class MapasControllerTest < ActionDispatch::IntegrationTest
    def auth(user = users(:kauam)) = { "Authorization" => "Bearer #{user.api_token}" }

    def mapa_json(id, title)
      { id: id, title: title, layout: "mapa", nodes: [{ id: "r", parent: nil, label: title, x: 0, y: 0 }] }.to_json
    end

    test "exige token" do
      get "/api/mapas"
      assert_response :unauthorized
    end

    test "lista só os mapas do usuário" do
      get "/api/mapas", headers: auth
      assert_response :success
      assert_equal [{ "id" => "mfunil001", "title" => "Funil GFB", "updatedAt" => 1_794_578_386_000 }], response.parsed_body

      get "/api/mapas", headers: auth(users(:outro))
      assert_equal [], response.parsed_body
    end

    test "abre um mapa com data em texto" do
      get "/api/mapas/mfunil001", headers: auth
      assert_response :success
      assert_equal "Funil GFB", JSON.parse(response.parsed_body["data"])["title"]
    end

    test "não abre mapa de outro usuário" do
      get "/api/mapas/mfunil001", headers: auth(users(:outro))
      assert_response :not_found
    end

    test "cria e depois atualiza pelo id do navegador" do
      put "/api/mapas/mnovo42", headers: auth, as: :json,
                                params: { title: "Novo", updatedAt: 1000, data: mapa_json("mnovo42", "Novo") }
      assert_response :success
      put "/api/mapas/mnovo42", headers: auth, as: :json,
                                params: { title: "Novo 2", updatedAt: 2000, data: mapa_json("mnovo42", "Novo 2") }
      assert_response :success

      mapa = users(:kauam).mapas.find_by!(client_id: "mnovo42")
      assert_equal "Novo 2", mapa.title
      assert_equal 2000, mapa.client_updated_at
      assert_equal "Novo 2", mapa.data["title"]
    end

    test "recusa data que não é mapa" do
      put "/api/mapas/mruim", headers: auth, as: :json, params: { title: "X", updatedAt: 1, data: "{\"foo\":1}" }
      assert_response :unprocessable_entity
    end

    test "exclui" do
      delete "/api/mapas/mfunil001", headers: auth
      assert_response :no_content
      assert_nil users(:kauam).mapas.find_by(client_id: "mfunil001")
    end
  end
end
