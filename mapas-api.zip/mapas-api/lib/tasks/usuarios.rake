# frozen_string_literal: true

namespace :usuarios do
  desc "Cria um usuário e mostra o token de acesso. Uso: bin/rails usuarios:criar NOME='Kauam' EMAIL='kauam@gfb.com.br'"
  task criar: :environment do
    user = User.create!(name: ENV.fetch("NOME"), email: ENV.fetch("EMAIL"))
    puts "Usuário criado: #{user.name} <#{user.email}>"
    puts "Token: #{user.api_token}"
    puts "Link de acesso: <URL_DO_APP>/?token=#{user.api_token}"
  end

  desc "Gera um novo token (invalida o antigo). Uso: bin/rails usuarios:novo_token EMAIL='...'"
  task novo_token: :environment do
    user = User.find_by!(email: ENV.fetch("EMAIL").strip.downcase)
    user.regenerate_api_token
    puts "Novo token: #{user.api_token}"
  end
end
