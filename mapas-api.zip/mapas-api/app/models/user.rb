# frozen_string_literal: true

class User < ApplicationRecord
  has_secure_token :api_token
  has_many :mapas, dependent: :destroy

  validates :name, presence: true
  validates :email, presence: true, uniqueness: { case_sensitive: false }

  normalizes :email, with: ->(e) { e.strip.downcase }
end
