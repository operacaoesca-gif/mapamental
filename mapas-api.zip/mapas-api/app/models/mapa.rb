# frozen_string_literal: true

class Mapa < ApplicationRecord
  belongs_to :user

  validates :client_id, presence: true,
                        format: { with: /\A[A-Za-z0-9_-]{1,64}\z/ },
                        uniqueness: { scope: :user_id }
  validates :title, presence: true, length: { maximum: 200 }
  validates :client_updated_at, presence: true
end
