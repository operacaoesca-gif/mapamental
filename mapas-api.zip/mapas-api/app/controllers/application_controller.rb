# frozen_string_literal: true

class ApplicationController < ActionController::API
  include ActionController::HttpAuthentication::Token::ControllerMethods

  before_action :authenticate!

  attr_reader :current_user

  private

  # Header esperado: Authorization: Bearer <api_token>
  def authenticate!
    @current_user = authenticate_with_http_token do |token, _options|
      User.find_by(api_token: token)
    end
    render json: { error: "unauthorized" }, status: :unauthorized unless @current_user
  end
end
