# frozen_string_literal: true

module Api
  # CRUD dos mapas no formato que o front-end usa:
  #   GET    /api/mapas      -> [{ id, title, updatedAt }]
  #   GET    /api/mapas/:id  -> { id, title, updatedAt, data: "<json do mapa>" }
  #   PUT    /api/mapas/:id  <- { title, updatedAt, data: "<json do mapa>" }   (cria ou atualiza)
  #   DELETE /api/mapas/:id
  # O :id é gerado no navegador (ex.: "mlx3k2a9f1b"), por isso guardamos em client_id.
  class MapasController < ApplicationController
    MAX_BYTES = 2 * 1024 * 1024

    def index
      mapas = current_user.mapas.order(client_updated_at: :desc)
                          .select(:client_id, :title, :client_updated_at)
      render json: mapas.map { |m| meta(m) }
    end

    def show
      mapa = current_user.mapas.find_by(client_id: params[:id])
      return render(json: { error: "not_found" }, status: :not_found) unless mapa

      render json: meta(mapa).merge(data: mapa.data.to_json)
    end

    def update
      raw = params[:data].to_s
      return render(json: { error: "too_large" }, status: 413) if raw.bytesize > MAX_BYTES

      parsed = parse_map(raw)
      return render(json: { error: "invalid_map" }, status: :unprocessable_entity) unless parsed

      mapa = current_user.mapas.find_or_initialize_by(client_id: params[:id])
      mapa.assign_attributes(
        title: params[:title].to_s.strip[0, 200].presence || "Sem título",
        client_updated_at: params[:updatedAt].to_i.positive? ? params[:updatedAt].to_i : (Time.current.to_f * 1000).to_i,
        data: parsed
      )

      if mapa.save
        render json: meta(mapa)
      else
        render json: { error: "invalid", details: mapa.errors.full_messages }, status: :unprocessable_entity
      end
    rescue ActiveRecord::RecordNotUnique
      retry # duas abas salvando o mesmo mapa ao mesmo tempo
    end

    def destroy
      current_user.mapas.where(client_id: params[:id]).delete_all
      head :no_content
    end

    private

    def meta(mapa)
      { id: mapa.client_id, title: mapa.title, updatedAt: mapa.client_updated_at }
    end

    def parse_map(raw)
      parsed = JSON.parse(raw)
      parsed.is_a?(Hash) && parsed["nodes"].is_a?(Array) ? parsed : nil
    rescue JSON::ParserError
      nil
    end
  end
end
