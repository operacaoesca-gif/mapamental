# frozen_string_literal: true

module Api
  # POST /api/mapas/gerar  <- { text: "transcrição...", focus: "processo" | "reuniao" | "ideias" }
  #                        -> { title, nodes: [{ label, note, children: [...] }] }
  class GeracoesController < ApplicationController
    # Rate limit nativo do Rails 8 (usa o Rails.cache). Roda depois do authenticate!.
    rate_limit to: 10, within: 1.minute, by: -> { current_user.id },
               with: -> { render json: { error: "rate_limited" }, status: :too_many_requests }

    def create
      result = Ia::MapaMentalGenerator.new.call(text: params.require(:text), focus: params[:focus])
      render json: result
    rescue ActionController::ParameterMissing, ArgumentError
      render json: { error: "empty_text" }, status: :unprocessable_entity
    rescue Ia::ClaudeClient::RateLimited
      render json: { error: "rate_limited" }, status: :too_many_requests
    rescue Ia::MapaMentalGenerator::InvalidOutput => e
      Rails.logger.warn("[mapas/gerar] saída inválida: #{e.message}")
      render json: { error: "empty" }, status: :bad_gateway
    rescue Ia::ClaudeClient::Error => e
      Rails.logger.error("[mapas/gerar] #{e.class}: #{e.message}")
      render json: { error: "ai_error" }, status: :bad_gateway
    end
  end
end
