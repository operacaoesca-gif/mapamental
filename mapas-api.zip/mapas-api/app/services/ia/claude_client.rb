# frozen_string_literal: true

require "net/http"
require "json"
require "uri"

module Ia
  # Cliente mínimo da Messages API da Anthropic, só com a stdlib (sem gem extra).
  # A chave fica no servidor (ENV["ANTHROPIC_API_KEY"]); o navegador nunca a vê.
  class ClaudeClient
    class Error < StandardError; end
    class RateLimited < Error; end
    class NotConfigured < Error; end

    ENDPOINT = URI("https://api.anthropic.com/v1/messages")
    API_VERSION = "2023-06-01"
    DEFAULT_MODEL = "claude-sonnet-5-5"

    def initialize(api_key: ENV["ANTHROPIC_API_KEY"],
                   model: ENV.fetch("ANTHROPIC_MODEL", DEFAULT_MODEL),
                   read_timeout: Integer(ENV.fetch("ANTHROPIC_TIMEOUT", "120")))
      @api_key = api_key.to_s
      @model = model
      @read_timeout = read_timeout
    end

    # Envia uma mensagem e devolve o texto da resposta.
    # Não enviamos temperature/top_p: os modelos atuais recusam valores fora do padrão.
    def message(system:, user:, max_tokens: 8_000)
      raise NotConfigured, "ANTHROPIC_API_KEY não definida" if @api_key.empty?

      request = Net::HTTP::Post.new(ENDPOINT)
      request["x-api-key"] = @api_key
      request["anthropic-version"] = API_VERSION
      request["content-type"] = "application/json"
      request.body = JSON.generate(
        model: @model,
        max_tokens: max_tokens,
        system: system,
        messages: [{ role: "user", content: user }]
      )

      response = Net::HTTP.start(ENDPOINT.host, ENDPOINT.port, use_ssl: true,
                                 open_timeout: 10, read_timeout: @read_timeout) do |http|
        http.request(request)
      end

      handle(response)
    rescue Net::OpenTimeout, Net::ReadTimeout => e
      raise Error, "Tempo esgotado falando com a Claude API (#{e.class})"
    end

    private

    def handle(response)
      code = response.code.to_i
      raise RateLimited, "Claude API #{code}" if [429, 529].include?(code)
      raise Error, "Claude API #{code}: #{response.body.to_s[0, 300]}" unless code == 200

      body = JSON.parse(response.body)
      raise Error, "Resposta cortada (max_tokens). Use um texto menor." if body["stop_reason"] == "max_tokens"

      Array(body["content"]).select { |b| b["type"] == "text" }.map { |b| b["text"] }.join
    rescue JSON::ParserError
      raise Error, "Resposta da Claude API não é JSON"
    end
  end
end
