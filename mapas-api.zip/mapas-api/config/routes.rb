# frozen_string_literal: true

Rails.application.routes.draw do
  get "up" => "rails/health#show", as: :rails_health_check

  namespace :api do
    # Precisa vir antes do resources, senão "gerar" seria lido como :id.
    post "mapas/gerar", to: "geracoes#create"
    resources :mapas, only: %i[index show update destroy]
  end
end
