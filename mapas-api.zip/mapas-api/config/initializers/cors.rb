# frozen_string_literal: true

# Só é necessário se o front-end ficar em outro domínio.
# Se você servir o HTML pelo próprio Rails (public/index.html), pode ignorar.
# Ex.: FRONTEND_ORIGINS=https://mapas.gestaofitness.com.br,http://localhost:5173
Rails.application.config.middleware.insert_before 0, Rack::Cors do
  allow do
    origins(*ENV.fetch("FRONTEND_ORIGINS", "http://localhost:3000").split(",").map(&:strip))
    resource "/api/*",
             headers: :any,
             methods: %i[get put post delete options],
             max_age: 600
  end
end
