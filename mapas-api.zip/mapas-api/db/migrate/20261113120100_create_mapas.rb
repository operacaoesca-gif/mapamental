# frozen_string_literal: true

class CreateMapas < ActiveRecord::Migration[8.0]
  def change
    create_table :mapas do |t|
      t.references :user, null: false, foreign_key: true
      t.string :client_id, null: false            # id gerado no navegador
      t.string :title, null: false, default: "Sem título"
      t.jsonb :data, null: false, default: {}     # o mapa inteiro (nós, layout, cores)
      t.bigint :client_updated_at, null: false    # updatedAt do navegador, em ms
      t.timestamps
    end
    add_index :mapas, %i[user_id client_id], unique: true
    add_index :mapas, %i[user_id client_updated_at]
  end
end
