/*
 * Adaptador do "Criador de mapas mentais" para o back-end Rails.
 *
 * O HTML original usa window.claude.use('db' | 'sample' | 'downloads'), que só existe
 * dentro do Claude. Este arquivo cria um window.claude compatível que fala com a API:
 *   db      -> /api/mapas (listar, abrir, salvar, excluir)
 *   sample  -> /api/mapas/gerar (IA; o prompt é montado no servidor)
 *   downloads -> não implementado: o app cai no download normal do navegador.
 *
 * Configuração (antes deste script):
 *   window.MAPA_API = { baseUrl: '' }   // '' = mesmo domínio do Rails
 * Token: abra o app uma vez com ?token=SEU_TOKEN (fica salvo no navegador).
 * Sem token válido, o app continua funcionando só com o armazenamento do navegador.
 */
(function () {
  'use strict';
  var cfg = window.MAPA_API || {};
  var base = String(cfg.baseUrl || '').replace(/\/$/, '');

  function readToken() {
    try {
      var params = new URLSearchParams(window.location.search);
      var q = params.get('token');
      if (q) {
        window.localStorage.setItem('mm:token', q);
        params.delete('token');
        var rest = params.toString();
        window.history.replaceState(null, '', window.location.pathname + (rest ? '?' + rest : '') + window.location.hash);
        return q;
      }
      return window.localStorage.getItem('mm:token') || cfg.token || '';
    } catch (e) {
      return cfg.token || '';
    }
  }
  var TOKEN = readToken();

  function fail(status, body) {
    var err = new Error((body && body.error) || ('HTTP ' + status));
    err.status = status;
    err.code = status === 429 ? 'rate_limited'
      : status === 401 || status === 403 ? 'not_granted'
      : (body && body.error) || ('http_' + status);
    return err;
  }

  function req(method, path, body) {
    var headers = { Accept: 'application/json' };
    if (body) headers['Content-Type'] = 'application/json';
    if (TOKEN) headers.Authorization = 'Bearer ' + TOKEN;
    return fetch(base + path, { method: method, headers: headers, body: body ? JSON.stringify(body) : undefined })
      .then(function (r) {
        if (r.status === 204) return null;
        return r.json().catch(function () { return {}; }).then(function (j) {
          if (!r.ok) throw fail(r.status, j);
          return j;
        });
      });
  }

  function docRef(path) {
    var id = encodeURIComponent(String(path).split('/')[1] || '');
    var url = '/api/mapas/' + id;
    return {
      get: function () {
        return req('GET', url).then(
          function (j) { return { exists: true, id: j.id, data: function () { return j; } }; },
          function (e) { if (e.status === 404) return { exists: false, data: function () { return undefined; } }; throw e; }
        );
      },
      set: function (d) { return req('PUT', url, d).then(function () {}); },
      delete: function () { return req('DELETE', url).then(function () {}); }
    };
  }

  var db = {
    collection: function () {
      return {
        get: function () {
          return req('GET', '/api/mapas').then(function (list) {
            return {
              docs: (list || []).map(function (m) {
                return { id: m.id, data: function () { return { title: m.title, updatedAt: m.updatedAt }; } };
              })
            };
          });
        }
      };
    },
    doc: docRef
  };

  // O app monta um prompt completo; aqui só extraímos o texto e o foco,
  // e o servidor monta o prompt dele. Assim a API não aceita prompts arbitrários.
  var FOCOS = [['MAPEAR UM PROCESSO', 'processo'], ['RESUMIR UMA REUNIÃO', 'reuniao'], ['ORGANIZAR IDEIAS', 'ideias']];
  var sample = {
    json: function (prompt) {
      var p = String(prompt || '');
      var m = p.match(/<<<INICIO>>>\n([\s\S]*)\n<<<FIM>>>\s*$/);
      var focus = 'processo';
      FOCOS.forEach(function (f) { if (p.indexOf('TAREFA: ' + f[0]) >= 0) focus = f[1]; });
      return req('POST', '/api/mapas/gerar', { text: m ? m[1] : '', focus: focus });
    }
  };

  window.claude = {
    use: function (name) {
      if (name === 'db') {
        if (!TOKEN) return Promise.reject(fail(401));
        // Testa o token; se falhar, o app segue só com o navegador.
        return req('GET', '/api/mapas').then(function () { return db; });
      }
      if (name === 'sample') {
        if (!TOKEN) return Promise.reject(fail(401));
        return Promise.resolve(sample);
      }
      return Promise.reject(fail(404, { error: 'unavailable' }));
    }
  };
})();
