# Back-end do Criador de Mapas Mentais (Rails 8 API + PostgreSQL)

The original HTML uses `window.claude` (which only exists inside Claude) to save maps and call the AI.
This backend replaces that, and the HTML in `public/index.html` already includes the adapter (`frontend/mapa-api.js`).

## O que o back-end faz

| Rota | Função |
|---|---|
| `GET /api/mapas` | Lista os mapas do usuário (`id`, `title`, `updatedAt`) |
| `GET /api/mapas/:id` | Abre um mapa (`data` = JSON do mapa em texto) |
| `PUT /api/mapas/:id` | Cria ou atualiza (o id vem do navegador) |
| `DELETE /api/mapas/:id` | Exclui |
| `POST /api/mapas/gerar` | Recebe `{ text, focus }` e devolve `{ title, nodes }` gerado pela Claude API |

Todas exigem `Authorization: Bearer <token>`. A chave da Anthropic fica só no servidor.
The prompt is built on the server, so the endpoint isn't an open AI proxy, and it's limited to 10 calls per minute per user.

## Passo a passo

### 1. Crie o app Rails

```bash
rails new mapas-api --api -d postgresql
cd mapas-api
```

### 2. Adicione a gem de CORS

In `Gemfile`, uncomment or add the line below, then run `bundle install`:

```ruby
gem "rack-cors"
```

### 3. Copy the files from this package into the project

```
app/controllers/application_controller.rb   (substitui o gerado)
app/controllers/api/mapas_controller.rb
app/controllers/api/geracoes_controller.rb
app/models/user.rb
app/models/mapa.rb
app/services/ia/claude_client.rb
app/services/ia/mapa_mental_generator.rb
config/routes.rb                            (substitui o gerado)
config/initializers/cors.rb                 (substitui o gerado)
db/migrate/20261113120000_create_users.rb
db/migrate/20261113120100_create_mapas.rb
lib/tasks/usuarios.rake
public/index.html                           (o front-end já com o adaptador)
test/...                                    (testes)
```

### 4. Configure as variáveis de ambiente

```bash
ANTHROPIC_API_KEY=sk-ant-...           # obrigatória para a IA
ANTHROPIC_MODEL=claude-sonnet-5-5      # opcional (padrão)
FRONTEND_ORIGINS=https://seu-front.com # só se o HTML ficar em outro domínio
DATABASE_URL=postgres://...            # em produção (ex.: Supabase)
```

### 5. Crie o banco e o primeiro usuário

```bash
bin/rails db:create db:migrate
bin/rails usuarios:criar NOME="Kauam" EMAIL="kauam@gfb.com.br"
```

The command prints the user's token.

### 6. Abra o app

```bash
bin/rails server
```

Acesse `http://localhost:3000/?token=SEU_TOKEN` uma vez. O token fica salvo no navegador e sai da URL.
From then on, "Meus mapas" says the maps are saved on any device, and the "Transcrição com IA" tab works.

### 7. Rode os testes

```bash
bin/rails test
```

## Observações

- **Hosting the HTML elsewhere:** in the HTML, change `window.MAPA_API = { baseUrl: "" }` to the API URL, and set `FRONTEND_ORIGINS`.
- **Request timeout:** AI generation can take up to about 1 minute. Platforms that cut requests at 30s (Heroku, for example) need a longer timeout or a background job.
- **No token:** the app still works, but only saves in the browser, just like the original.
- **Rate limit:** Rails 8's `rate_limit` uses `Rails.cache`. In production, use a shared cache (Solid Cache, which is Rails 8's default, or Redis).
